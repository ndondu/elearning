<?php
   
   $conn = mysqli_connect('localhost','root','',"moon_db");
   if(!$conn){
       echo 'could not connect to database';
      
   }
?>