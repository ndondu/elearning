<?php
session_start();
include_once '../includes/connect.php';
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $result = mysqli_query($conn, "SELECT * FROM users_table where email='" . $_POST['email'] . "'");
    $row = mysqli_fetch_assoc($result);
    $fetch_email = $row['email'];
    $email_id = $row['email'];
    $password = $row['password'];
    if ($email == $fetch_email) {
        $to = $email_id;
        $subject = "Password";
        $txt = "Your password is : $password.";
        $headers = "From: ndondugrace88@gmail.com" . "\r\n" .
            "CC: ndondugrace88@gmail.com";
        mail($to, $subject, $txt, $headers);
    } else {
        echo 'invalid userid';
    }
}
?>
<!DOCTYPE HTML>
<html>

<head>
    <style type="text/css">
        input {
            border: 1px solid olive;
            border-radius: 5px;
        }

        h1 {
            color: darkgreen;
            font-size: 22px;
            text-align: center;
        }
    </style>
</head>

<body>
    <h1>Forgot Password<h1>
            <form action='forget.php' method='post'>
                <table cellspacing='5' align='center'>
                    <tr>
                        <td>user id:</td>
                        <td><input type='email' name='email' /></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type='submit' name='submit' value='Submit' /></td>
                    </tr>
                </table>
            </form>
</body>

</html>